"""
MCP Tools integration.

To add a real MCP server:
  1. pip install mcp
  2. Implement arun() in a BaseMCPTool subclass using ClientSession
  3. Register in get_mcp_tools()
"""
from __future__ import annotations

import ast
import operator
import re


# ── Safe AST-based evaluator (replaces eval()) ─────────────────────

_OPERATORS = {
    ast.Add:  operator.add,
    ast.Sub:  operator.sub,
    ast.Mult: operator.mul,
    ast.Div:  operator.truediv,
    ast.Pow:  operator.pow,
    ast.USub: operator.neg,
}


def _safe_eval(expr: str) -> float:
    """Evaluate arithmetic using AST — no arbitrary code execution."""
    def _eval(node):
        if isinstance(node, ast.Constant):
            return node.n
        elif isinstance(node, ast.BinOp):
            op = _OPERATORS.get(type(node.op))
            if op is None:
                raise ValueError(f"Unsupported operator: {node.op}")
            return op(_eval(node.left), _eval(node.right))
        elif isinstance(node, ast.UnaryOp):
            op = _OPERATORS.get(type(node.op))
            if op is None:
                raise ValueError(f"Unsupported operator: {node.op}")
            return op(_eval(node.operand))
        else:
            raise ValueError(f"Unsupported expression: {type(node)}")

    tree = ast.parse(expr.strip(), mode="eval")
    return _eval(tree.body)


# ── Base tool interface ────────────────────────────────────────────

class BaseMCPTool:
    name: str = "base"
    description: str = ""

    async def arun(self, query: str) -> str:
        raise NotImplementedError


# ── Tool implementations ───────────────────────────────────────────

class WebSearchTool(BaseMCPTool):
    name = "web_search"
    description = "Search the web for up-to-date information."

    async def arun(self, query: str) -> str:
        # Wire to a real MCP server here, e.g.:
        # from mcp import ClientSession, StdioServerParameters
        # from mcp.client.stdio import stdio_client
        # server = StdioServerParameters(command="uvx", args=["mcp-server-brave-search"])
        # async with stdio_client(server) as (r, w):
        #     async with ClientSession(r, w) as session:
        #         await session.initialize()
        #         result = await session.call_tool("brave_web_search", {"query": query})
        #         return result.content[0].text
        return ""


class CalculatorTool(BaseMCPTool):
    """Arithmetic evaluator using AST — safe, no eval()."""
    name = "calculator"
    description = "Evaluate basic arithmetic expressions."

    async def arun(self, query: str) -> str:
        match = re.search(r"[\d\s\+\-\*\/\(\)\.]+", query)
        if not match:
            return ""
        try:
            expr   = match.group().strip()
            result = _safe_eval(expr)
            return f"{expr} = {result}"
        except Exception:
            return ""


class DocumentMetadataTool(BaseMCPTool):
    name = "doc_metadata"
    description = "Fetch metadata for a document by ID."

    async def arun(self, query: str) -> str:
        return ""


_TOOLS: list[BaseMCPTool] = [
    WebSearchTool(),
    CalculatorTool(),
    DocumentMetadataTool(),
]


def get_mcp_tools() -> list[BaseMCPTool]:
    return _TOOLS
