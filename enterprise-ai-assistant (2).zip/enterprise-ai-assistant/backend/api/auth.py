import os
import secrets
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer, APIKeyHeader
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

# ── Config ─────────────────────────────────────────────────────────
SECRET_KEY      = os.getenv("JWT_SECRET_KEY", secrets.token_hex(32))
ALGORITHM       = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

VALID_API_KEYS  = set(os.getenv("API_KEYS", "dev-key-1,dev-key-2").split(","))

pwd_context    = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer_scheme  = HTTPBearer(auto_error=False)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


# ── Models ─────────────────────────────────────────────────────────
class TokenData(BaseModel):
    username: Optional[str] = None
    scopes: list[str] = []

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ── JWT helpers ────────────────────────────────────────────────────
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> TokenData:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        scopes: list  = payload.get("scopes", [])
        if username is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
        return TokenData(username=username, scopes=scopes)
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")


# ── Dependency: accepts Bearer JWT OR API key ──────────────────────
async def get_current_user(
    bearer: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme),
    api_key: Optional[str] = Security(api_key_header),
) -> TokenData:
    if api_key:
        if api_key in VALID_API_KEYS:
            return TokenData(username="api-key-user", scopes=["read", "write"])
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid API key")
    if bearer:
        return decode_token(bearer.credentials)
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required. Provide Bearer token or X-API-Key header.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def require_scope(scope: str):
    def checker(user: TokenData = Depends(get_current_user)) -> TokenData:
        if scope not in user.scopes:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                                detail=f"Scope '{scope}' required")
        return user
    return checker
