from fastapi import APIRouter
from qdrant_client import AsyncQdrantClient
import httpx

from api.config import get_settings

router = APIRouter()
settings = get_settings()


@router.get("/health")
async def health_check():
    status = {"api": "ok", "qdrant": "unknown", "ollama": "unknown"}

    # Check Qdrant
    try:
        client = AsyncQdrantClient(host=settings.qdrant_host, port=settings.qdrant_port)
        await client.get_collections()
        status["qdrant"] = "ok"
    except Exception as e:
        status["qdrant"] = f"error: {str(e)}"

    # Check Ollama
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            if resp.status_code == 200:
                models   = [m["name"] for m in resp.json().get("models", [])]
                # Fix 6: exact match instead of substring to avoid false positives
                # e.g. "llama3.1:8b" should not match "llama3.1:8b-instruct"
                model_ok = any(
                    m == settings.ollama_model or m.startswith(settings.ollama_model + ":")
                    for m in models
                )
                status["ollama"]        = "ok"
                status["ollama_models"] = models
                status["ollama_model_ready"] = model_ok
                if not model_ok:
                    status["ollama_warning"] = f"Model '{settings.ollama_model}' not found. Run: ollama pull {settings.ollama_model}"
    except Exception as e:
        status["ollama"] = f"error: {str(e)}"

    return status
