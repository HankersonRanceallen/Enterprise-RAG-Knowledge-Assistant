import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.auth import TokenData, get_current_user
from api.monitoring import ACTIVE_QUERIES, QUERY_LATENCY
from pipeline.graph import build_rag_graph

router    = APIRouter()
rag_graph = build_rag_graph()


class QueryRequest(BaseModel):
    question:   str
    doc_filter: Optional[str] = None
    top_k:      Optional[int] = 5
    session_id: Optional[str] = None


class SourceChunk(BaseModel):
    doc_id:   str
    filename: str
    page:     int
    text:     str
    score:    float


class QueryResponse(BaseModel):
    answer:             str
    sources:            list[SourceChunk]
    guardrail_triggered: bool
    latency_ms:         float


@router.post("/query", response_model=QueryResponse)
async def query_documents(
    req: QueryRequest,
    current_user: TokenData = Depends(get_current_user),
):
    if not req.question.strip():
        raise HTTPException(400, "Question cannot be empty.")

    ACTIVE_QUERIES.inc()
    t0 = time.time()
    try:
        result = await rag_graph.ainvoke({
            "question":            req.question,
            "doc_filter":          req.doc_filter,
            "top_k":               req.top_k or 5,
            "context":             [],
            "answer":              "",
            "guardrail_triggered": False,
            "guardrail_reason":    "",
        })
    finally:
        ACTIVE_QUERIES.dec()
        QUERY_LATENCY.observe(time.time() - t0)

    latency = (time.time() - t0) * 1000

    sources = [
        SourceChunk(
            doc_id=c["doc_id"],
            filename=c["filename"],
            page=c["page"],
            text=c["text"],
            score=c["score"],
        )
        for c in result.get("context", [])
    ]

    return QueryResponse(
        answer=result["answer"],
        sources=sources,
        guardrail_triggered=result.get("guardrail_triggered", False),
        latency_ms=round(latency, 1),
    )
