import json
import os
import uuid
from typing import Optional

import aiofiles
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from api.auth import TokenData, get_current_user
from api.config import get_settings
from api.queue import get_queue
from pipeline.vectorstore import delete_document_chunks, list_documents

router   = APIRouter()
settings = get_settings()


class UploadResponse(BaseModel):
    doc_id:     str
    filename:   str
    status:     str         # "queued"
    status_url: str


class IngestStatus(BaseModel):
    doc_id:  str
    status:  str            # "queued" | "complete" | "failed"
    chunks:  Optional[int] = None
    error:   Optional[str] = None


class DocumentInfo(BaseModel):
    doc_id:     str
    filename:   str
    chunk_count: int


@router.post("/documents/upload", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    current_user: TokenData = Depends(get_current_user),
    queue=Depends(get_queue),
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Only PDF files are supported.")

    doc_id    = str(uuid.uuid4())
    os.makedirs(settings.upload_dir, exist_ok=True)
    save_path = os.path.join(settings.upload_dir, f"{doc_id}_{file.filename}")

    size = 0
    async with aiofiles.open(save_path, "wb") as f:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > settings.max_file_size_mb * 1024 * 1024:
                os.remove(save_path)
                raise HTTPException(413, f"File exceeds {settings.max_file_size_mb} MB limit.")
            await f.write(chunk)

    # Enqueue — returns immediately, worker handles the slow work
    await queue.enqueue_job(
        "task_ingest_pdf",
        path=save_path,
        doc_id=doc_id,
        filename=file.filename,
    )

    return UploadResponse(
        doc_id=doc_id,
        filename=file.filename,
        status="queued",
        status_url=f"/api/v1/documents/{doc_id}/status",
    )


@router.get("/documents/{doc_id}/status", response_model=IngestStatus)
async def get_ingest_status(
    doc_id: str,
    current_user: TokenData = Depends(get_current_user),
    queue=Depends(get_queue),
):
    raw = await queue.redis.get(f"ingest_status:{doc_id}")
    if raw is None:
        return IngestStatus(doc_id=doc_id, status="queued")
    data = json.loads(raw)
    return IngestStatus(
        doc_id=doc_id,
        status=data.get("status", "unknown"),
        chunks=data.get("chunks"),
        error=data.get("error"),
    )


@router.get("/documents", response_model=list[DocumentInfo])
async def get_documents(current_user: TokenData = Depends(get_current_user)):
    return await list_documents()


@router.delete("/documents/{doc_id}")
async def delete_document(
    doc_id: str,
    current_user: TokenData = Depends(get_current_user),
):
    deleted = await delete_document_chunks(doc_id)
    return {"doc_id": doc_id, "chunks_deleted": deleted}
