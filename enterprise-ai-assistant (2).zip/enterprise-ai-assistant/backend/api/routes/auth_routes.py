from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm

from api.auth import (
    ACCESS_TOKEN_EXPIRE_MINUTES, Token, TokenData,
    create_access_token, get_current_user, pwd_context,
)

router = APIRouter()

# Fake user DB — replace with a real DB in production
FAKE_USERS = {
    "admin": {
        "username": "admin",
        "hashed_password": pwd_context.hash("adminpassword"),
        "scopes": ["read", "write", "admin"],
    },
    "reader": {
        "username": "reader",
        "hashed_password": pwd_context.hash("readerpassword"),
        "scopes": ["read"],
    },
}


@router.post("/auth/token", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = FAKE_USERS.get(form_data.username)
    if not user or not pwd_context.verify(form_data.password, user["hashed_password"]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Incorrect username or password")
    token = create_access_token(
        data={"sub": user["username"], "scopes": user["scopes"]},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    return Token(access_token=token)


@router.get("/auth/me", response_model=TokenData)
async def read_me(current_user: TokenData = Depends(get_current_user)):
    return current_user
