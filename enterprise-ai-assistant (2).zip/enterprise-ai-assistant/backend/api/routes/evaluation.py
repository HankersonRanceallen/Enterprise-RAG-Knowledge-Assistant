from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from evaluation.metrics import run_evaluation

router = APIRouter()


class EvalSample(BaseModel):
    question: str
    ground_truth: str
    answer: str
    contexts: list[str]


class EvalRequest(BaseModel):
    samples: list[EvalSample]


class EvalMetrics(BaseModel):
    faithfulness: float
    answer_relevancy: float
    context_precision: float
    context_recall: float
    sample_count: int


@router.post("/evaluate", response_model=EvalMetrics)
async def evaluate_rag(req: EvalRequest):
    """
    Run RAGAS evaluation on a set of QA samples.
    Each sample needs: question, ground_truth, answer, contexts.
    """
    metrics = await run_evaluation(req.samples)
    return metrics


@router.get("/evaluate/demo")
async def evaluate_demo():
    """Return pre-computed demo metrics for the dashboard."""
    return EvalMetrics(
        faithfulness=0.87,
        answer_relevancy=0.91,
        context_precision=0.83,
        context_recall=0.79,
        sample_count=50,
    )
