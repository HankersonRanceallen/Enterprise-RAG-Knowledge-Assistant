import time

from fastapi import APIRouter, Response
from prometheus_client import (
    Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST,
)
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

# ── Metrics ────────────────────────────────────────────────────────

REQUEST_COUNT = Counter(
    "rag_http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status_code"],
)

REQUEST_LATENCY = Histogram(
    "rag_http_request_duration_seconds",
    "HTTP request latency",
    ["endpoint"],
    buckets=[0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
)

QUERY_LATENCY = Histogram(
    "rag_query_duration_seconds",
    "End-to-end RAG query latency",
    buckets=[0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0],
)

RETRIEVAL_SCORE = Histogram(
    "rag_retrieval_score",
    "Cosine similarity score of retrieved chunks",
    buckets=[0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
)

RETRIEVAL_CHUNKS = Histogram(
    "rag_retrieval_chunks_returned",
    "Number of chunks returned per query",
    buckets=[0, 1, 2, 3, 4, 5, 7, 10],
)

GUARDRAIL_TRIGGERS = Counter(
    "rag_guardrail_triggers_total",
    "Times guardrails fired",
    ["stage"],
)

INGEST_COUNT = Counter(
    "rag_documents_ingested_total",
    "Total documents successfully ingested",
)

INGEST_CHUNKS = Counter(
    "rag_chunks_ingested_total",
    "Total chunks upserted to Qdrant",
)

INGEST_LATENCY = Histogram(
    "rag_ingest_duration_seconds",
    "PDF ingest pipeline latency",
    buckets=[1, 5, 10, 30, 60, 120],
)

ACTIVE_QUERIES = Gauge(
    "rag_active_queries",
    "Currently running RAG queries",
)

QUEUE_DEPTH = Gauge(
    "rag_ingest_queue_depth",
    "Number of pending ingest jobs",
)


# ── Middleware ─────────────────────────────────────────────────────

class PrometheusMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start    = time.time()
        response = await call_next(request)
        duration = time.time() - start

        endpoint = request.url.path
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=endpoint,
            status_code=response.status_code,
        ).inc()
        REQUEST_LATENCY.labels(endpoint=endpoint).observe(duration)

        return response


# ── /metrics endpoint ──────────────────────────────────────────────

router = APIRouter()

@router.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
