from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # Qdrant
    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    collection_name: str = "enterprise_docs"
    vector_size: int = 384  # all-MiniLM-L6-v2 output dim

    # Ollama
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.1:8b"
    ollama_temperature: float = 0.1
    ollama_num_ctx: int = 4096

    # Embeddings
    embedding_model: str = "all-MiniLM-L6-v2"

    # Chunking
    chunk_size: int = 512
    chunk_overlap: int = 64

    # RAG retrieval
    top_k: int = 5
    similarity_threshold: float = 0.5

    # Guardrails
    max_response_tokens: int = 1024
    guardrails_enabled: bool = True

    # Uploads
    upload_dir: str = "uploads"
    max_file_size_mb: int = 50

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
