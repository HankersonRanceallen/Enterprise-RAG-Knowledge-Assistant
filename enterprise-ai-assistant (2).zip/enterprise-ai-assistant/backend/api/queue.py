import os
import arq.connections

REDIS_SETTINGS = arq.connections.RedisSettings(
    host=os.getenv("REDIS_HOST", "localhost"),
    port=int(os.getenv("REDIS_PORT", 6379)),
)

_pool = None


async def get_queue():
    global _pool
    if _pool is None:
        _pool = await arq.connections.create_pool(REDIS_SETTINGS)
    return _pool
