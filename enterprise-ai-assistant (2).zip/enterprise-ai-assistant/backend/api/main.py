from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.config import get_settings
from api.monitoring import PrometheusMiddleware, router as metrics_router
from api.routes import documents, evaluation, health, query
from api.routes.auth_routes import router as auth_router
from pipeline.vectorstore import init_collection

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 Starting Enterprise AI Assistant backend...")
    await init_collection()
    print("✅ Vector store ready")
    yield
    print("🛑 Shutting down")


app = FastAPI(
    title="Enterprise AI Knowledge Assistant",
    description="RAG-powered document Q&A with LangGraph, Qdrant, and Ollama",
    version="2.0.0",
    lifespan=lifespan,
)

# Middleware
app.add_middleware(PrometheusMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(health.router,       prefix="/api/v1", tags=["health"])
app.include_router(auth_router,         prefix="/api/v1", tags=["auth"])
app.include_router(documents.router,    prefix="/api/v1", tags=["documents"])
app.include_router(query.router,        prefix="/api/v1", tags=["query"])
app.include_router(evaluation.router,   prefix="/api/v1", tags=["evaluation"])
app.include_router(metrics_router,      prefix="/api/v1", tags=["monitoring"])
