from __future__ import annotations

import asyncio
from typing import TypedDict

import httpx
from langgraph.graph import END, StateGraph

from api.config import get_settings
from api.monitoring import (
    GUARDRAIL_TRIGGERS, RETRIEVAL_CHUNKS, RETRIEVAL_SCORE,
)
from guardrails.checker import check_input, check_output
from pipeline.ingestor import get_embedder
from pipeline.vectorstore import similarity_search
from tools.mcp_tools import get_mcp_tools

settings = get_settings()


class RAGState(TypedDict):
    question:            str
    doc_filter:          str | None
    top_k:               int
    context:             list[dict]
    answer:              str
    guardrail_triggered: bool
    guardrail_reason:    str


async def node_guardrail_input(state: RAGState) -> RAGState:
    triggered, reason = check_input(state["question"])
    if triggered:
        GUARDRAIL_TRIGGERS.labels(stage="input").inc()
        return {**state, "guardrail_triggered": True, "guardrail_reason": reason,
                "answer": f"Request blocked: {reason}", "context": []}
    return {**state, "guardrail_triggered": False, "guardrail_reason": ""}


async def node_retrieve(state: RAGState) -> RAGState:
    loop    = asyncio.get_event_loop()
    embedder = get_embedder()
    q_vec   = await loop.run_in_executor(
        None, lambda: embedder.encode([state["question"]])[0].tolist()
    )
    chunks = await similarity_search(
        q_vec,
        top_k=state["top_k"],
        doc_filter=state.get("doc_filter"),
    )
    RETRIEVAL_CHUNKS.observe(len(chunks))
    for c in chunks:
        RETRIEVAL_SCORE.observe(c["score"])
    return {**state, "context": chunks}


async def node_mcp_tools(state: RAGState) -> RAGState:
    tools        = get_mcp_tools()
    tool_results = []
    for tool in tools:
        try:
            result = await tool.arun(state["question"])
            if result:
                tool_results.append(f"[{tool.name}]: {result}")
        except Exception:
            pass
    return {**state, "tool_results": tool_results}


def _build_prompt(question: str, context: list[dict], tool_results: list[str]) -> str:
    ctx_block = "\n\n".join(
        f"[Source: {c['filename']} p.{c['page']}]\n{c['text']}" for c in context
    ) or "No relevant documents found."
    tool_block = ("\n\nAdditional context from tools:\n" + "\n".join(tool_results)) if tool_results else ""
    return f"""You are an enterprise knowledge assistant. Answer the question using ONLY the provided context.
If the context does not contain enough information, say so clearly.
Be concise, accurate, and cite source documents when possible.

Context:
{ctx_block}{tool_block}

Question: {question}

Answer:"""


async def node_generate(state: RAGState) -> RAGState:
    prompt = _build_prompt(
        state["question"],
        state.get("context", []),
        state.get("tool_results", []),
    )
    # Fix 8: graceful exception handling so a crashed Ollama returns a clean error
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{settings.ollama_base_url}/api/generate",
                json={
                    "model":  settings.ollama_model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": settings.ollama_temperature,
                        "num_ctx":     settings.ollama_num_ctx,
                        "num_predict": settings.max_response_tokens,
                    },
                },
            )
            resp.raise_for_status()
            answer = resp.json().get("response", "").strip()
    except httpx.TimeoutException:
        answer = "Generation timed out. The model may be overloaded — please try again."
    except httpx.HTTPStatusError as e:
        answer = f"Ollama returned an error: HTTP {e.response.status_code}"
    except Exception as e:
        answer = f"Generation failed: {e}"
    return {**state, "answer": answer}


async def node_guardrail_output(state: RAGState) -> RAGState:
    if not settings.guardrails_enabled:
        return state
    triggered, reason = check_output(state["answer"])
    if triggered:
        GUARDRAIL_TRIGGERS.labels(stage="output").inc()
        return {**state, "guardrail_triggered": True, "guardrail_reason": reason,
                "answer": f"Response blocked by output guardrails: {reason}"}
    return state


async def node_blocked(state: RAGState) -> RAGState:
    return state


def route_after_input_guardrail(state: RAGState) -> str:
    return "blocked" if state["guardrail_triggered"] else "retrieve"


def build_rag_graph():
    g = StateGraph(RAGState)
    g.add_node("guardrail_input",  node_guardrail_input)
    g.add_node("retrieve",         node_retrieve)
    g.add_node("mcp_tools",        node_mcp_tools)
    g.add_node("generate",         node_generate)
    g.add_node("guardrail_output", node_guardrail_output)
    g.add_node("blocked",          node_blocked)

    g.set_entry_point("guardrail_input")
    g.add_conditional_edges("guardrail_input", route_after_input_guardrail,
                             {"retrieve": "retrieve", "blocked": "blocked"})
    g.add_edge("retrieve",         "mcp_tools")
    g.add_edge("mcp_tools",        "generate")
    g.add_edge("generate",         "guardrail_output")
    g.add_edge("guardrail_output", END)
    g.add_edge("blocked",          END)
    return g.compile()
