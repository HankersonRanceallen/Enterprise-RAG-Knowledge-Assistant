import asyncio
import hashlib
import time
from pathlib import Path
from typing import Any, Optional

import pdfplumber
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer

from api.config import get_settings
from api.monitoring import INGEST_CHUNKS, INGEST_COUNT, INGEST_LATENCY
from pipeline.vectorstore import upsert_chunks

settings = get_settings()

_embedder: Optional[SentenceTransformer] = None
_vector_size: Optional[int] = None

# Fix 3: sentence-aware splitter replaces character-level chunking
_splitter = RecursiveCharacterTextSplitter(
    chunk_size=settings.chunk_size,
    chunk_overlap=settings.chunk_overlap,
    separators=["\n\n", "\n", ". ", "! ", "? ", " ", ""],
)

# Fix 5: in-memory duplicate hash store (use Redis/DB in production)
_ingested_hashes: dict[str, str] = {}


def get_embedder() -> SentenceTransformer:
    global _embedder
    if _embedder is None:
        print(f"Loading embedding model: {settings.embedding_model}")
        _embedder = SentenceTransformer(settings.embedding_model)
    return _embedder


def get_vector_size() -> int:
    """Fix 2: detect vector size dynamically from the loaded model."""
    global _vector_size
    if _vector_size is None:
        embedder    = get_embedder()
        probe       = embedder.encode(["probe"], show_progress_bar=False)
        _vector_size = len(probe[0])
        print(f"Detected vector size: {_vector_size}")
    return _vector_size


def hash_file(path: str) -> str:
    """Fix 5: SHA-256 hash of file contents for duplicate detection."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


def extract_text_from_pdf(path: str) -> list[dict[str, Any]]:
    pages = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages):
            text = page.extract_text() or ""
            if text.strip():
                pages.append({"page": i + 1, "text": text})
    return pages


def chunk_text(text: str) -> list[str]:
    """Fix 3: use RecursiveCharacterTextSplitter instead of raw char slicing."""
    return [c.strip() for c in _splitter.split_text(text) if c.strip()]


async def ingest_document(path: str, doc_id: str, filename: str) -> int:
    # Fix 5: check for duplicate before doing any work
    file_hash = hash_file(path)
    if file_hash in _ingested_hashes:
        existing_id = _ingested_hashes[file_hash]
        print(f"⚠️  Duplicate detected: {filename} already ingested as doc_id={existing_id}")
        return 0

    t0   = time.time()
    loop = asyncio.get_event_loop()

    pages = await loop.run_in_executor(None, extract_text_from_pdf, path)

    raw_chunks: list[dict] = []
    for page_data in pages:
        for chunk in chunk_text(page_data["text"]):
            raw_chunks.append({"page": page_data["page"], "text": chunk})

    if not raw_chunks:
        return 0

    embedder   = get_embedder()
    texts      = [c["text"] for c in raw_chunks]
    embeddings = await loop.run_in_executor(
        None, lambda: embedder.encode(texts, batch_size=32, show_progress_bar=False).tolist()
    )

    chunks_to_upsert = [
        {
            "embedding": embeddings[i],
            "doc_id":    doc_id,
            "filename":  filename,
            "page":      raw_chunks[i]["page"],
            "text":      raw_chunks[i]["text"],
        }
        for i in range(len(raw_chunks))
    ]

    await upsert_chunks(chunks_to_upsert)

    # Register hash after successful ingest
    _ingested_hashes[file_hash] = doc_id

    INGEST_COUNT.inc()
    INGEST_CHUNKS.inc(len(chunks_to_upsert))
    INGEST_LATENCY.observe(time.time() - t0)

    return len(chunks_to_upsert)
