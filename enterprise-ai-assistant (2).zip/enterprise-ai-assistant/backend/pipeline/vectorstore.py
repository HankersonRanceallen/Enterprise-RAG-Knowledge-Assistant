from typing import Any, Optional
import uuid

from qdrant_client import AsyncQdrantClient
from qdrant_client.http.models import (
    Distance, FieldCondition, Filter, MatchValue,
    PointStruct, VectorParams,
)

from api.config import get_settings

settings = get_settings()
_client: Optional[AsyncQdrantClient] = None


def get_client() -> AsyncQdrantClient:
    global _client
    if _client is None:
        _client = AsyncQdrantClient(
            host=settings.qdrant_host,
            port=settings.qdrant_port,
        )
    return _client


async def init_collection():
    """Fix 2: detect vector size dynamically instead of using hardcoded constant."""
    from pipeline.ingestor import get_vector_size
    vector_size = get_vector_size()

    client      = get_client()
    collections = await client.get_collections()
    names       = [c.name for c in collections.collections]

    if settings.collection_name not in names:
        await client.create_collection(
            collection_name=settings.collection_name,
            vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE),
        )
        print(f"Created Qdrant collection: {settings.collection_name} (dim={vector_size})")
    else:
        info = await client.get_collection(settings.collection_name)
        print(f"Collection exists: {settings.collection_name} — {info.points_count} points")


async def upsert_chunks(chunks: list[dict[str, Any]]):
    client = get_client()
    points = [
        PointStruct(
            id=str(uuid.uuid4()),
            vector=chunk["embedding"],
            payload={
                "doc_id":   chunk["doc_id"],
                "filename": chunk["filename"],
                "page":     chunk["page"],
                "text":     chunk["text"],
            },
        )
        for chunk in chunks
    ]
    await client.upsert(collection_name=settings.collection_name, points=points)


async def similarity_search(
    query_vector: list[float],
    top_k: int = 5,
    doc_filter: Optional[str] = None,
) -> list[dict]:
    client = get_client()

    qdrant_filter = None
    if doc_filter:
        qdrant_filter = Filter(
            must=[FieldCondition(key="doc_id", match=MatchValue(value=doc_filter))]
        )

    results = await client.search(
        collection_name=settings.collection_name,
        query_vector=query_vector,
        limit=top_k,
        query_filter=qdrant_filter,
        with_payload=True,
        score_threshold=settings.similarity_threshold,
    )

    return [
        {
            "doc_id":   r.payload["doc_id"],
            "filename": r.payload["filename"],
            "page":     r.payload["page"],
            "text":     r.payload["text"],
            "score":    r.score,
        }
        for r in results
    ]


async def list_documents() -> list[dict]:
    client = get_client()
    seen: dict[str, dict] = {}
    offset = None

    while True:
        points, next_offset = await client.scroll(
            collection_name=settings.collection_name,
            limit=100,
            offset=offset,
            with_payload=True,
        )
        for p in points:
            doc_id = p.payload["doc_id"]
            if doc_id not in seen:
                seen[doc_id] = {
                    "doc_id":      doc_id,
                    "filename":    p.payload["filename"],
                    "chunk_count": 1,
                }
            else:
                seen[doc_id]["chunk_count"] += 1
        if next_offset is None:
            break
        offset = next_offset

    return list(seen.values())


async def delete_document_chunks(doc_id: str) -> int:
    client = get_client()
    result = await client.delete(
        collection_name=settings.collection_name,
        points_selector=Filter(
            must=[FieldCondition(key="doc_id", match=MatchValue(value=doc_id))]
        ),
    )
    return result.operation_id or 0
