"""
Evaluation module using RAGAS.

Metrics computed:
  - Faithfulness: does the answer stick to the retrieved context?
  - Answer Relevancy: how relevant is the answer to the question?
  - Context Precision: are retrieved chunks relevant?
  - Context Recall: does context cover the ground truth?

RAGAS requires an LLM judge. We point it at Ollama via a LangChain wrapper.
For large eval sets, consider running offline in a batch job.
"""
from __future__ import annotations

from typing import Any

from api.config import get_settings

settings = get_settings()


async def run_evaluation(samples: list[Any]) -> dict:
    """
    Run RAGAS evaluation on a list of EvalSample objects.
    Returns metric dict with keys: faithfulness, answer_relevancy,
    context_precision, context_recall, sample_count.

    Note: RAGAS calls are synchronous internally; we wrap them here.
    For large datasets, offload to a background task.
    """
    try:
        from datasets import Dataset
        from ragas import evaluate
        from ragas.metrics import (
            faithfulness,
            answer_relevancy,
            context_precision,
            context_recall,
        )
        from langchain_community.llms import Ollama
        from langchain_community.embeddings import OllamaEmbeddings

        data = {
            "question": [s.question for s in samples],
            "answer": [s.answer for s in samples],
            "contexts": [s.contexts for s in samples],
            "ground_truth": [s.ground_truth for s in samples],
        }
        dataset = Dataset.from_dict(data)

        llm = Ollama(
            base_url=settings.ollama_base_url,
            model=settings.ollama_model,
        )
        embeddings = OllamaEmbeddings(
            base_url=settings.ollama_base_url,
            model=settings.ollama_model,
        )

        result = evaluate(
            dataset=dataset,
            metrics=[faithfulness, answer_relevancy, context_precision, context_recall],
            llm=llm,
            embeddings=embeddings,
        )

        return {
            "faithfulness": float(result["faithfulness"]),
            "answer_relevancy": float(result["answer_relevancy"]),
            "context_precision": float(result["context_precision"]),
            "context_recall": float(result["context_recall"]),
            "sample_count": len(samples),
        }

    except Exception as e:
        # Return placeholder metrics if RAGAS call fails (e.g. Ollama not ready)
        return {
            "faithfulness": 0.0,
            "answer_relevancy": 0.0,
            "context_precision": 0.0,
            "context_recall": 0.0,
            "sample_count": len(samples),
            "error": str(e),
        }
