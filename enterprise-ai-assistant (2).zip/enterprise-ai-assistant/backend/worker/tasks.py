import json
import os

import arq.connections

from pipeline.ingestor import ingest_document


async def task_ingest_pdf(ctx, *, path: str, doc_id: str, filename: str) -> dict:
    """
    ARQ background task. Runs in the worker process.
    ctx["redis"] is injected by ARQ.
    """
    print(f"[worker] Starting ingest: {filename} (doc_id={doc_id})")
    try:
        chunks = await ingest_document(path, doc_id, filename)
        result = {"status": "complete", "doc_id": doc_id, "chunks": chunks}
        print(f"[worker] Done: {chunks} chunks indexed for {filename}")
    except Exception as e:
        result = {"status": "failed", "doc_id": doc_id, "error": str(e)}
        print(f"[worker] Failed for {doc_id}: {e}")

    # Write result to Redis so the API status endpoint can read it
    await ctx["redis"].setex(
        f"ingest_status:{doc_id}",
        3600,                   # TTL 1 hour
        json.dumps(result),
    )
    return result


class WorkerSettings:
    redis_settings = arq.connections.RedisSettings(
        host=os.getenv("REDIS_HOST", "localhost"),
        port=int(os.getenv("REDIS_PORT", 6379)),
    )
    functions  = [task_ingest_pdf]
    max_jobs   = 4      # concurrent ingest jobs
    job_timeout = 300   # 5 min max per job
