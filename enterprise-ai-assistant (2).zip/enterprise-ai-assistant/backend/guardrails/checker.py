"""
Guardrails module.

Provides lightweight, fast rule-based checks for input and output.
For production, layer in guardrails-ai validators or a dedicated
moderation endpoint on top of these.

Input checks:
  - Prompt injection patterns
  - Explicit jailbreak phrases
  - Extreme query length

Output checks:
  - PII leakage (basic regex: SSN, credit card)
  - Profanity (stub, extend as needed)
  - Hallucination signal phrases
"""
from __future__ import annotations

import re

# ─────────────────────────────────────────────
# Patterns
# ─────────────────────────────────────────────

_INJECTION_PATTERNS = [
    r"ignore\s+(all\s+)?previous\s+instructions",
    r"disregard\s+(all\s+)?prior\s+instructions",
    r"you\s+are\s+now\s+(DAN|an?\s+AI\s+without\s+restrictions)",
    r"pretend\s+you\s+are\s+(not\s+an?\s+AI|a\s+human)",
    r"system\s*prompt\s*[:=]",
    r"<\s*system\s*>",
    r"\[INST\].*bypass",
]

_PII_PATTERNS = [
    r"\b\d{3}-\d{2}-\d{4}\b",          # SSN
    r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b",  # credit card
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b",  # email
]

_HALLUCINATION_SIGNALS = [
    "as of my knowledge cutoff",
    "i don't have access to real",
    "i cannot verify",
    "i'm not sure but i believe",
]

MAX_QUERY_LENGTH = 2000


# ─────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────

def check_input(text: str) -> tuple[bool, str]:
    """
    Returns (triggered: bool, reason: str).
    triggered=True means the request should be blocked.
    """
    if len(text) > MAX_QUERY_LENGTH:
        return True, f"Query too long ({len(text)} chars, max {MAX_QUERY_LENGTH})"

    lower = text.lower()
    for pattern in _INJECTION_PATTERNS:
        if re.search(pattern, lower):
            return True, f"Possible prompt injection detected (pattern: {pattern[:40]})"

    return False, ""


def check_output(text: str) -> tuple[bool, str]:
    """
    Returns (triggered: bool, reason: str).
    triggered=True means the response should be suppressed.
    """
    for pattern in _PII_PATTERNS:
        if re.search(pattern, text):
            return True, "Response may contain PII"

    # Hallucination signal — log but don't block (flip to True to block)
    lower = text.lower()
    for signal in _HALLUCINATION_SIGNALS:
        if signal in lower:
            # Warn only; production teams may choose to block
            pass

    return False, ""
