"""
Enterprise AI Knowledge Assistant — Streamlit UI
"""
import os
import time
import streamlit as st
import requests

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")
API = f"{BACKEND_URL}/api/v1"

# ─────────────────────────────────────────────
# Page config
# ─────────────────────────────────────────────

st.set_page_config(
    page_title="Enterprise AI Knowledge Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────
# Custom CSS
# ─────────────────────────────────────────────

st.markdown("""
<style>
    .stApp { background: #0f1117; }
    .main-header {
        background: linear-gradient(135deg, #1e3a5f 0%, #0d2137 100%);
        border: 1px solid #2a5080;
        border-radius: 12px;
        padding: 24px 32px;
        margin-bottom: 24px;
    }
    .metric-card {
        background: #1a1f2e;
        border: 1px solid #2a3655;
        border-radius: 8px;
        padding: 16px;
        text-align: center;
    }
    .source-card {
        background: #141824;
        border-left: 3px solid #3b82f6;
        border-radius: 4px;
        padding: 12px 16px;
        margin: 8px 0;
        font-size: 0.85rem;
    }
    .guardrail-badge {
        background: #7f1d1d;
        border: 1px solid #ef4444;
        border-radius: 6px;
        padding: 4px 12px;
        font-size: 0.8rem;
        color: #fca5a5;
    }
    .status-ok { color: #4ade80; }
    .status-err { color: #f87171; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────

st.markdown("""
<div class="main-header">
    <h1 style="margin:0; color:#e2e8f0; font-size:1.8rem;">🧠 Enterprise AI Knowledge Assistant</h1>
    <p style="margin:4px 0 0; color:#94a3b8; font-size:0.95rem;">
        RAG · LangGraph · Ollama (Llama 3.1 8B) · Qdrant
    </p>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# Sidebar: upload + document list + settings
# ─────────────────────────────────────────────

with st.sidebar:
    st.header("📂 Documents")

    uploaded = st.file_uploader("Upload PDF", type=["pdf"], label_visibility="collapsed")
    if uploaded:
        with st.spinner(f"Ingesting {uploaded.name}…"):
            try:
                resp = requests.post(
                    f"{API}/documents/upload",
                    files={"file": (uploaded.name, uploaded.getvalue(), "application/pdf")},
                    timeout=120,
                )
                resp.raise_for_status()
                data = resp.json()
                st.success(f"✅ {data['chunks_created']} chunks indexed")
                st.cache_data.clear()
            except Exception as e:
                st.error(f"Upload failed: {e}")

    st.divider()

    @st.cache_data(ttl=10)
    def fetch_documents():
        try:
            return requests.get(f"{API}/documents", timeout=10).json()
        except Exception:
            return []

    docs = fetch_documents()
    if docs:
        st.subheader(f"Indexed Documents ({len(docs)})")
        for doc in docs:
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"📄 **{doc['filename']}**  \n`{doc['chunk_count']} chunks`")
            with col2:
                if st.button("🗑", key=f"del_{doc['doc_id']}", help="Remove"):
                    try:
                        requests.delete(f"{API}/documents/{doc['doc_id']}", timeout=10)
                        st.cache_data.clear()
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
    else:
        st.info("No documents ingested yet. Upload a PDF above.")

    st.divider()
    st.subheader("⚙️ Settings")
    top_k = st.slider("Retrieved chunks (top-k)", 1, 10, 5)
    doc_filter_options = ["All documents"] + [d["doc_id"] for d in docs]
    doc_filter_labels = ["All documents"] + [d["filename"] for d in docs]
    selected_idx = st.selectbox(
        "Restrict to document",
        range(len(doc_filter_options)),
        format_func=lambda i: doc_filter_labels[i],
    )
    doc_filter = None if selected_idx == 0 else doc_filter_options[selected_idx]

    st.divider()
    # Health check
    try:
        health = requests.get(f"{API}/health", timeout=5).json()
        qdrant_ok = health.get("qdrant") == "ok"
        ollama_ok = health.get("ollama") == "ok"
        st.markdown(
            f"{'🟢' if qdrant_ok else '🔴'} Qdrant &nbsp;&nbsp;"
            f"{'🟢' if ollama_ok else '🔴'} Ollama",
            unsafe_allow_html=True,
        )
        if ollama_ok:
            models = health.get("ollama_models", [])
            if models:
                st.caption(f"Models: {', '.join(models[:3])}")
    except Exception:
        st.markdown("🔴 Backend offline")

# ─────────────────────────────────────────────
# Main area: tabs
# ─────────────────────────────────────────────

tab_chat, tab_eval = st.tabs(["💬 Chat", "📊 Evaluation Dashboard"])

# ── Chat tab ──────────────────────────────────
with tab_chat:
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Render history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("sources"):
                with st.expander(f"📎 {len(msg['sources'])} source(s)", expanded=False):
                    for src in msg["sources"]:
                        st.markdown(
                            f'<div class="source-card">'
                            f'<b>{src["filename"]}</b> · page {src["page"]} '
                            f'· score {src["score"]:.2f}<br>'
                            f'<small>{src["text"][:300]}{"…" if len(src["text"]) > 300 else ""}</small>'
                            f'</div>',
                            unsafe_allow_html=True,
                        )
            if msg.get("guardrail_triggered"):
                st.markdown('<span class="guardrail-badge">⚠️ Guardrail triggered</span>', unsafe_allow_html=True)
            if msg.get("latency_ms"):
                st.caption(f"⏱ {msg['latency_ms']} ms")

    # Input
    if prompt := st.chat_input("Ask a question about your documents…"):
        if not docs:
            st.warning("Upload at least one PDF before querying.")
        else:
            st.session_state.messages.append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)

            with st.chat_message("assistant"):
                with st.spinner("Thinking…"):
                    try:
                        resp = requests.post(
                            f"{API}/query",
                            json={
                                "question": prompt,
                                "doc_filter": doc_filter,
                                "top_k": top_k,
                            },
                            timeout=120,
                        )
                        resp.raise_for_status()
                        data = resp.json()

                        st.markdown(data["answer"])

                        sources = data.get("sources", [])
                        if sources:
                            with st.expander(f"📎 {len(sources)} source(s)", expanded=False):
                                for src in sources:
                                    st.markdown(
                                        f'<div class="source-card">'
                                        f'<b>{src["filename"]}</b> · page {src["page"]} '
                                        f'· score {src["score"]:.2f}<br>'
                                        f'<small>{src["text"][:300]}{"…" if len(src["text"]) > 300 else ""}</small>'
                                        f'</div>',
                                        unsafe_allow_html=True,
                                    )

                        if data.get("guardrail_triggered"):
                            st.markdown('<span class="guardrail-badge">⚠️ Guardrail triggered</span>', unsafe_allow_html=True)

                        st.caption(f"⏱ {data['latency_ms']} ms")

                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": data["answer"],
                            "sources": sources,
                            "guardrail_triggered": data.get("guardrail_triggered", False),
                            "latency_ms": data.get("latency_ms"),
                        })

                    except Exception as e:
                        err_msg = f"Error: {e}"
                        st.error(err_msg)
                        st.session_state.messages.append({"role": "assistant", "content": err_msg})

    if st.button("🗑 Clear chat", key="clear_chat"):
        st.session_state.messages = []
        st.rerun()

# ── Evaluation Dashboard tab ──────────────────
with tab_eval:
    st.subheader("RAG Evaluation Dashboard")
    st.markdown("Run RAGAS metrics against a set of QA samples to measure pipeline quality.")

    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("#### Add evaluation samples")
        eval_q = st.text_input("Question")
        eval_gt = st.text_input("Ground truth answer")
        if st.button("Add sample") and eval_q and eval_gt:
            if "eval_samples" not in st.session_state:
                st.session_state.eval_samples = []
            st.session_state.eval_samples.append({
                "question": eval_q,
                "ground_truth": eval_gt,
            })
            st.success("Sample added.")

        samples = st.session_state.get("eval_samples", [])
        if samples:
            st.markdown(f"**{len(samples)} sample(s) queued**")
            for i, s in enumerate(samples[:5]):
                st.markdown(f"- `{s['question'][:60]}…`")
            if len(samples) > 5:
                st.caption(f"…and {len(samples) - 5} more")

    with col2:
        st.markdown("#### Run evaluation")
        use_demo = st.checkbox("Use demo metrics", value=True)

        if st.button("▶ Run RAGAS Eval", use_container_width=True):
            with st.spinner("Running evaluation…"):
                try:
                    if use_demo:
                        metrics = requests.get(f"{API}/evaluate/demo", timeout=10).json()
                    else:
                        # Auto-run pipeline on each sample to get answers + contexts
                        run_samples = []
                        for s in st.session_state.get("eval_samples", []):
                            r = requests.post(
                                f"{API}/query",
                                json={"question": s["question"], "top_k": 5},
                                timeout=120,
                            ).json()
                            run_samples.append({
                                "question": s["question"],
                                "ground_truth": s["ground_truth"],
                                "answer": r.get("answer", ""),
                                "contexts": [src["text"] for src in r.get("sources", [])],
                            })
                        metrics = requests.post(
                            f"{API}/evaluate",
                            json={"samples": run_samples},
                            timeout=300,
                        ).json()
                    st.session_state.eval_metrics = metrics
                    st.success("Evaluation complete!")
                except Exception as e:
                    st.error(f"Eval failed: {e}")

    # Display metrics
    if metrics_data := st.session_state.get("eval_metrics"):
        st.divider()
        st.subheader("Results")

        m1, m2, m3, m4 = st.columns(4)
        def metric_color(v):
            if v >= 0.8: return "#4ade80"
            if v >= 0.6: return "#facc15"
            return "#f87171"

        for col, key, label in [
            (m1, "faithfulness", "Faithfulness"),
            (m2, "answer_relevancy", "Answer Relevancy"),
            (m3, "context_precision", "Context Precision"),
            (m4, "context_recall", "Context Recall"),
        ]:
            val = metrics_data.get(key, 0)
            color = metric_color(val)
            with col:
                st.markdown(
                    f'<div class="metric-card">'
                    f'<div style="color:#94a3b8;font-size:0.8rem">{label}</div>'
                    f'<div style="color:{color};font-size:2rem;font-weight:700">{val:.2f}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

        st.caption(f"Evaluated on {metrics_data.get('sample_count', 0)} samples")

        if err := metrics_data.get("error"):
            st.warning(f"Eval warning: {err}")
