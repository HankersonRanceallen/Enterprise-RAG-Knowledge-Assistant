# Enterprise AI Knowledge Assistant

A production-grade RAG system with PDF ingestion, LangGraph workflow orchestration,
local LLM inference via Ollama, Qdrant vector search, guardrails, and a RAGAS
evaluation dashboard — all deployable with a single Docker Compose command.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  Streamlit UI (port 8501)                                        │
│   ├── Chat tab (Q&A + source attribution)                        │
│   └── Evaluation Dashboard (RAGAS metrics)                       │
└────────────────────┬─────────────────────────────────────────────┘
                     │ HTTP
┌────────────────────▼─────────────────────────────────────────────┐
│  FastAPI Backend (port 8000)                                      │
│   ├── POST /api/v1/documents/upload  → ingestor → Qdrant         │
│   ├── POST /api/v1/query             → LangGraph graph           │
│   └── POST /api/v1/evaluate          → RAGAS                     │
└──────┬─────────────────┬────────────────────┬────────────────────┘
       │                 │                    │
┌──────▼──────┐  ┌───────▼────────┐  ┌───────▼──────────────────┐
│  Qdrant     │  │  Ollama        │  │  MCP Tools               │
│  (port 6333)│  │  (port 11434)  │  │  (WebSearch, Calc, …)    │
│  Vector DB  │  │  Llama 3.1 8B  │  │  Plug-in via BaseMCPTool │
└─────────────┘  └────────────────┘  └──────────────────────────┘
```

### LangGraph RAG Pipeline

```
[question]
    │
    ▼
guardrail_input   ──(blocked)──► blocked ──► END
    │
    ▼
retrieve           (embed query → Qdrant similarity search)
    │
    ▼
mcp_tools          (best-effort tool augmentation)
    │
    ▼
generate           (Ollama prompt with context)
    │
    ▼
guardrail_output  ──(blocked)──► END
    │
    ▼
   END
```

---

## Quick Start

### Prerequisites

- Docker + Docker Compose
- 8 GB+ RAM (16 GB recommended for Llama 3.1 8B)
- ~5 GB disk for the model

### 1. Clone and start

```bash
git clone <this-repo>
cd enterprise-ai-assistant
chmod +x scripts/start.sh
./scripts/start.sh
```

The start script will:
1. Start Qdrant and Ollama containers
2. Pull the `llama3.1:8b` model (one-time, ~4.7 GB)
3. Start the FastAPI backend and Streamlit frontend

### 2. Open the UI

| Service         | URL                          |
|-----------------|------------------------------|
| Chat UI         | http://localhost:8501        |
| API docs        | http://localhost:8000/docs   |
| Qdrant dashboard| http://localhost:6333/dashboard |

### 3. Use it

1. Upload a PDF in the sidebar
2. Ask questions in the chat
3. View source attributions (page, score, text excerpt)
4. Check the Evaluation Dashboard tab

---

## Configuration

All settings are in `backend/api/config.py` and overridable via environment variables
in `docker-compose.yml`:

| Variable             | Default            | Description                    |
|----------------------|--------------------|--------------------------------|
| `OLLAMA_MODEL`       | `llama3.1:8b`      | Any model available in Ollama  |
| `OLLAMA_BASE_URL`    | `http://ollama:11434` | Ollama endpoint             |
| `QDRANT_HOST`        | `qdrant`           | Qdrant hostname                |
| `CHUNK_SIZE`         | `512`              | Characters per chunk           |
| `CHUNK_OVERLAP`      | `64`               | Overlap between chunks         |
| `TOP_K`              | `5`                | Retrieved chunks per query     |
| `GUARDRAILS_ENABLED` | `true`             | Toggle output guardrails       |

---

## Project Structure

```
enterprise-ai-assistant/
├── docker-compose.yml
├── scripts/
│   └── start.sh
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── api/
│   │   ├── main.py          # FastAPI app + lifespan
│   │   ├── config.py        # Settings (pydantic-settings)
│   │   └── routes/
│   │       ├── health.py
│   │       ├── documents.py
│   │       ├── query.py
│   │       └── evaluation.py
│   ├── pipeline/
│   │   ├── graph.py         # LangGraph RAG workflow ⭐
│   │   ├── ingestor.py      # PDF → chunks → embeddings
│   │   └── vectorstore.py   # Qdrant async client
│   ├── tools/
│   │   └── mcp_tools.py     # MCP tool stubs + calculator
│   ├── guardrails/
│   │   └── checker.py       # Input + output guardrails
│   └── evaluation/
│       └── metrics.py       # RAGAS evaluation runner
└── frontend/
    ├── Dockerfile
    ├── requirements.txt
    └── app.py               # Streamlit chat + eval dashboard
```

---

## Extending the System

### Add a new Ollama model

```bash
docker exec ollama ollama pull mistral:7b
# Then update OLLAMA_MODEL in docker-compose.yml
```

### Wire a real MCP tool

Edit `backend/tools/mcp_tools.py`. Implement `arun()` in any `BaseMCPTool` subclass:

```python
class BraveSearchTool(BaseMCPTool):
    name = "web_search"

    async def arun(self, query: str) -> str:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
        server = StdioServerParameters(command="uvx", args=["mcp-server-brave-search"])
        async with stdio_client(server) as (r, w):
            async with ClientSession(r, w) as session:
                await session.initialize()
                result = await session.call_tool("brave_web_search", {"query": query})
                return result.content[0].text
```

### Add a guardrail

Edit `backend/guardrails/checker.py`. Add patterns to `_INJECTION_PATTERNS` (input)
or `_PII_PATTERNS` (output), or call `guardrails-ai` validators:

```python
from guardrails import Guard
from guardrails.hub import ToxicLanguage

guard = Guard().use(ToxicLanguage, threshold=0.5, on_fail="exception")

def check_output(text: str) -> tuple[bool, str]:
    try:
        guard.validate(text)
        return False, ""
    except Exception as e:
        return True, str(e)
```

### Run evaluation against your own QA set

```bash
curl -X POST http://localhost:8000/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "samples": [{
      "question": "What is the refund policy?",
      "ground_truth": "30-day full refund.",
      "answer": "You can get a refund within 30 days.",
      "contexts": ["Our policy allows refunds within 30 days of purchase."]
    }]
  }'
```

---

## GPU Support

Uncomment the `deploy` block in `docker-compose.yml` under the `ollama` service:

```yaml
deploy:
  resources:
    reservations:
      devices:
        - driver: nvidia
          count: 1
          capabilities: [gpu]
```

---

## Tech Stack

| Component       | Technology                        |
|-----------------|-----------------------------------|
| Workflow        | LangGraph 0.1                     |
| LLM             | Ollama + Llama 3.1 8B             |
| Embeddings      | sentence-transformers (MiniLM-L6) |
| Vector DB       | Qdrant                            |
| Backend API     | FastAPI + uvicorn                 |
| Frontend UI     | Streamlit                         |
| Evaluation      | RAGAS                             |
| Guardrails      | Rule-based + guardrails-ai ready  |
| Deployment      | Docker Compose                    |
