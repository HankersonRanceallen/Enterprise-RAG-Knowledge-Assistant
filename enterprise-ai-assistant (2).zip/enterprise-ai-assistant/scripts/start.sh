#!/usr/bin/env bash
set -e

MODEL="llama3.1:8b"

echo "🐳 Starting core services..."
docker compose up -d qdrant ollama redis

echo "⏳ Waiting for Ollama..."
until curl -sf http://localhost:11434/api/tags > /dev/null 2>&1; do sleep 2; done

echo "📥 Pulling model: $MODEL ..."
docker exec ollama ollama pull "$MODEL"

echo "🚀 Starting all services..."
docker compose up -d

echo ""
echo "✅ All services up!"
echo ""
echo "  Frontend (Streamlit):  http://localhost:8501"
echo "  Backend  (FastAPI):    http://localhost:8000"
echo "  API docs:              http://localhost:8000/docs"
echo "  Qdrant dashboard:      http://localhost:6333/dashboard"
echo "  Prometheus:            http://localhost:9090"
echo "  Grafana:               http://localhost:3000  (admin/admin)"
echo ""
echo "  Get a JWT token:"
echo '  curl -X POST http://localhost:8000/api/v1/auth/token \'
echo '    -d "username=admin&password=adminpassword"'
echo ""
